#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import sys
import os
import re
import zipfile
import json
import urllib.request
from urllib.request import urlopen
from typing import Iterable
import subprocess

xbmc.log(f"REMOD TV INICIO", level=xbmc.LOGINFO)
### info del addon remodtv incluido en la app (special://xbmc)
remodtv_addon = xbmcaddon.Addon('plugin.program.remodtv')
remodtv_addon_id = remodtv_addon.getAddonInfo('id')
remodtv_addon_path = remodtv_addon.getAddonInfo('path')
remodtv_addon_name = remodtv_addon.getAddonInfo('name')
remodtv_addon_version = remodtv_addon.getAddonInfo('version')
### ruta caprpeta datos
remodtv_addon_datos = os.path.join(remodtv_addon_path, 'datos')
### special://home/addons
addons_home = xbmcvfs.translatePath(f'special://home/addons')
### special://home/userdata
addons_userdata = xbmcvfs.translatePath(f'special://home/userdata')
### special://home/userdata/addon_data
addons_addon_data = os.path.join(addons_userdata, 'addon_data')
### changelog
changelog = os.path.join(remodtv_addon_path, 'changelog.txt')
carp = 'dir'

### comp versión Kodi
def obtener_version_kodi():
    # Obtiene la cadena completa de la versión
    version_completa = xbmc.getInfoLabel('System.BuildVersion')
    
    # Normalmente la versión está al principio, antes de cualquier texto adicional
    # Por ejemplo: "21.0 Git:20211231" -> "21.0"
    version = version_completa.split()[0]   # toma solo la primera palabra
    
    # Si quieres separar mayor y menor:
    mayor, *resto = version.split('.')
    menor = resto[0] if resto else '0'
    
    return {
        'versión_completa': version_completa,
        'versión': version,
        'mayor': int(mayor),
        'menor': int(menor)
    }

# kodi info
info = obtener_version_kodi()
if info['mayor'] >= 20:
    xbmc.log(f"{remodtv_addon_name} Kodi 20+.", level=xbmc.LOGINFO)
else:
    xbmc.log(f"{remodtv_addon_name} Kodi <20.", level=xbmc.LOGINFO)
    xbmc.executebuiltin(f"Notification({remodtv_addon_name},ERROR. Kodi <20,3000,)")
    dialog = xbmcgui.Dialog()
    dialog.ok(f"{remodtv_addon_name}", "ERROR. Este addon no es compatible con versiones de Kodi <20.")
    sys.exit(0)

    
    
### parametros
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2][1:])  ### elimina el '?' inicial

### Construye una URL interna del addon a partir de un dict
def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)


### lista del menu pirncipal
def lista_menu_principal():
    ### Cada tupla contiene: etiqueta visible, acción, nombre del archivo de icono
    menu_items = [
        (f"{remodtv_addon_name} versión: {remodtv_addon_version} | Buscar actualizaciones", "info", "info.png"),
        ("> Instalar y configurar sección TV de Kodi | Reinstalar fuente por defecto", "tv2", "tv2.png"),
        ("> Elegir fuente para sección TV de Kodi", "fuente", "tv.png"),
        ("", "", ""),
        ("> Actualizar TV", "actualizar", "update.png"),
        # ("", "", ""),
        ("> Configurar Reproductor Externo para AceStream | Android y Windows", "res_ext", "repro.png")
        # ("> test", "test", "repro.png")
    ]

    for label, action, icon_file in menu_items:
        url = build_url({"action": action})
        ### Creamos el ListItem
        li = xbmcgui.ListItem(label=label)
        ### Ruta absoluta al icono
        icon_path = xbmcvfs.translatePath(os.path.join(remodtv_addon_path, 'recursos', 'imagenes', icon_file))
        ###  Asignamos el icono
        li.setArt({'icon': icon_path, 'thumb': icon_path})   # thumb también sirve
        ### Indicamos que es una carpeta (un sub‑menú o acción que abre algo)
        xbmcplugin.addDirectoryItem(handle=HANDLE,
                                    url=url,
                                    listitem=li,
                                    isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)
    

### mostrar changelog
def mostrar_changelog():
    xbmc.log(f"{remodtv_addon_name} Mostrando changelog.", level=xbmc.LOGINFO)
    try:
        with open(changelog, 'r', encoding='utf-8') as f:
            contenido = f.read()
    except Exception as e:
        xbmcgui.Dialog().notification(
            addon.getAddonInfo('name'),
            f'No se pudo leer changelog.txt: {e}',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        return
    # Muestra el texto en un visor de diálogos
    dlg = xbmcgui.Dialog()
    dlg.textviewer('Changelog', contenido)


### control de versión
VERSION_FILE = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s" % remodtv_addon_id), "last_version.json")

def leer_ultima_version():
    """Lee la versión que guardamos la última vez que se ejecutó el script."""
    if not os.path.isfile(VERSION_FILE):
        return None
    try:
        with open(VERSION_FILE, "r") as f:
            data = json.load(f)
            return data.get("version")
    except Exception as e:
        xbmc.log("REMOD TV Error leyendo versión guardada: %s" % e, xbmc.LOGERROR)
        return None


def guardar_version(version):
    """Guarda la versión actual para la próxima comparación."""
    os.makedirs(os.path.dirname(VERSION_FILE), exist_ok=True)
    try:
        with open(VERSION_FILE, "w") as f:
            json.dump({"version": version}, f)
    except Exception as e:
        xbmc.log("REMOD TV Error guardando versión: %s" % e, xbmc.LOGERROR)


def comp_version():
    # version_actual = obtener_version_instalada()
    version_actual = remodtv_addon_version
    version_anterior = leer_ultima_version()

    xbmc.log("REMOD TV Versión actual: %s" % version_actual, xbmc.LOGINFO)

    if version_anterior is None:
        xbmc.log("REMOD TV No hay registro previo. Guardando versión actual.", xbmc.LOGINFO)
        guardar_version(version_actual)
        return

    xbmc.log("REMOD TV Versión guardada previamente: %s" % version_anterior, xbmc.LOGINFO)

    if version_actual != version_anterior:
        xbmc.log("REMOD TV El addon se ha actualizado", xbmc.LOGINFO)
        ### Modificaciones
        mostrar_changelog()
        xbmcgui.Dialog().notification(f"{remodtv_addon_name}","Actualizado de v%s->[COLOR blue]v%s[/COLOR]" % (version_anterior, version_actual),xbmcgui.NOTIFICATION_INFO,5000)
        # Finalmente, actualizamos el registro
        guardar_version(version_actual)
    else:
        xbmc.log("REMOD TV No hay cambios de versión.", xbmc.LOGINFO)

### comrpobación de versión
xbmc.log(f"REMOD TV Comprobando actualización.", level=xbmc.LOGINFO)
comp_version()


### copia los archivos de configuración
def archivos_config():
    xbmc.log(f"REMOD TV Desactivando addons para copiar archivos de configuración.", level=xbmc.LOGINFO)
    xbmc.log(f"REMOD TV Copiando archivos de configuración inicial.", level=xbmc.LOGINFO)
    orig = xbmcvfs.translatePath(os.path.join(remodtv_addon_datos, 'pvr.iptvsimple', carp, 'instance-settings-2.xml'))
    dest = xbmcvfs.translatePath(os.path.join(addons_addon_data, 'pvr.iptvsimple', 'instance-settings-1.xml'))
    xbmcvfs.delete(dest)
    xbmcvfs.copy(orig, dest)
    dest = xbmcvfs.translatePath(os.path.join(addons_addon_data, 'pvr.iptvsimple', 'settings.xml'))
    xbmcvfs.delete(dest)
    xbmc.executebuiltin(f"Notification({remodtv_addon_name},Archivos de configuración copiados,3000,)")
    xbmc.log(f"{remodtv_addon_name} Archivos de configuración copiados.", level=xbmc.LOGINFO)

   
### des/activación de addons
def addon_act_des(addon_id: str, enable: bool) -> None:
    xbmc.log(f"REMOD TV: {'Activando' if enable else 'Desactivando'} {addon_id}",
             level=xbmc.LOGINFO)
    request = ('{'
               '"jsonrpc":"2.0",'
               '"method":"Addons.SetAddonEnabled",'
               f'"params":{{"addonid":"{addon_id}","enabled":{str(enable).lower()}}},'
               '"id":1}'
               )
    xbmc.executeJSONRPC(request)

### lista de addons iterable
def lista_addons(addon_ids: Iterable[str], enable: bool) -> None:
    for aid in addon_ids:
        try:
            addon_act_des(aid, enable)
            return True
        except Exception as e:
            xbmc.log(f"REMOD TV: Error con {aid}: {e}", level=xbmc.LOGERROR)
            return False

### acer click en yes en diálogo de confirmación
def addon_activacion_confirm(addon_id):
    max_attempts = 10  # Número máximo de intentos
    attempts = 0
    while attempts < max_attempts:
         xbmc.log(f"REMOD TV Intentando click yes para activar addon zip", level=xbmc.LOGINFO)
         # Verificar si el diálogo de confirmación está visible
         if xbmc.getCondVisibility(f"Window.IsVisible(10100)"):
            xbmc.log(f"REMOD TV Espereando visibilidad botón yes para activar addon zip", level=xbmc.LOGINFO)
            xbmc.executebuiltin(f"SendClick(11)", True)
            xbmc.sleep(1000)
            xbmcvfs.copy(orig, dest)
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},Addon activado.,1000,)")
            xbmc.log(f"REMOD TV Intentando click yes para activar addon zip", level=xbmc.LOGINFO)
            return True
         else:   
            xbmc.sleep(500)  # Pequeña pausa entre intentos
            attempts += 1
    return False
   
### descarga de zip
def download_zip_from_url(url):
    xbmc.executebuiltin(f"Notification({remodtv_addon_name},Descargando addon.,1000,)")
    xbmc.log(f"REMOD TV Iniciando download_zip_from_url.", level=xbmc.LOGINFO)
    try:
        # Realizar la solicitud HTTP GET
        response = urllib.request.urlopen(url)
        # Extraer el nombre del archivo desde la URL
        filename = url.split('/')[-1]
        # Ruta donde se guardará el archivo
        addon_path = xbmcvfs.translatePath(os.path.join(addons_home, 'packages'))
        # global full_path
        full_path = os.path.join(addon_path, filename)
        # Guardar el archivo en el sistema local
        with open(full_path, 'wb') as f:
            f.write(response.read())
            xbmc.log(f"REMOD TV Archivo zip descargado.", level=xbmc.LOGINFO)
        xbmc.log(f"REMOD TV Fin download_zip_from_url.", level=xbmc.LOGINFO)
        xbmc.log(f"REMOD TV Iniciando extract_zip.", level=xbmc.LOGINFO)
        xbmc.sleep(1000)
        extract_path = xbmcvfs.translatePath(addons_home)
        # Verificar si el archivo existe
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"El archivo {full_path} no existe")
            return False
        # Extraer el archivo ZIP
        with zipfile.ZipFile(full_path, mode="r") as archive:
            archive.extractall(extract_path)
            xbmc.log(f"REMOD TV Archivo zip extraido.", level=xbmc.LOGINFO)
        xbmc.log(f"REMOD TV Fin extract_zip.", level=xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"REMOD TV Error al extraer archivo.", level=xbmc.LOGINFO)
        xbmc.executebuiltin(f"Notification({remodtv_addon_name},Error al extraer archivo.,3000,)")
        return False
    
    
def inst_addon(addon_id):
    ### verificamos que no esté instalado ya
    if xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
        xbmc.executebuiltin(f"Notification({remodtv_addon_name},{addon_id} ya instalado.,1000,)")
        xbmc.log(f"El addon {addon_id} está ya instalado. Desinstalando", level=xbmc.LOGINFO)
        return False
    else:
        xbmc.log(f"El addon {addon_id} no está instalado.", level=xbmc.LOGINFO)
        xbmc.executebuiltin(f"Notification({remodtv_addon_name},Instalando {addon_id}.,1000,)")
        xbmc.log(f"REMOD TV Instalando addon.", level=xbmc.LOGINFO)
        instalar = f"InstallAddon({addon_id}, True)"
        xbmc.executebuiltin(instalar)
        xbmc.sleep(500)
        return True

def addon_inst_confirm(addon_id):
    max_attempts = 10  # Número máximo de intentos
    attempts = 0
    while attempts < max_attempts:
        xbmc.log(f"REMOD TV Intentando click yes", level=xbmc.LOGINFO)
        # Verificar si el diálogo de confirmación está visible
        if xbmc.getCondVisibility(f"Window.IsVisible(10100)"):
            xbmc.log(f"REMOD TV Esperando visibilidad botón yes", level=xbmc.LOGINFO)
            # Simular pulsación del botón Yes
            xbmc.executebuiltin(f"SendClick(11)", True)
            max_attempts2 = 20  # Número máximo de intentos
            attempts2 = 0
            while attempts2 < max_attempts2:
                if xbmc.getCondVisibility(f"Window.IsVisible(10101)"):
                    xbmc.log(f"REMOD TV Se está instalando", level=xbmc.LOGINFO)
                    max_attempts3 = 200  # Número máximo de intentos
                    attempts3 = 0
                    while attempts3 < max_attempts3:
                        if not xbmc.getCondVisibility(f"Window.IsVisible(10101)"):
                            xbmc.log(f"{remodtv_addon_name} instalado", level=xbmc.LOGINFO)
                            xbmc.executebuiltin(f"Notification({remodtv_addon_name},Instalado.,1000,)")
                            return True
                        else:
                            xbmc.log(f"REMOD TV Se está terminado de instalar", level=xbmc.LOGINFO)
                            xbmc.sleep(100)
                            attempts3 += 1
                else:
                    xbmc.sleep(500)  # Pequeña pausa entre intentos
                    attempts2 += 1
            xbmc.log(f"Tiempo max superado {addon_id}.", level=xbmc.LOGINFO)
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},Tiempo superado.,1000,)")
            return True    
        xbmc.sleep(500)  # Pequeña pausa entre intentos
        attempts += 1
    return False
        

### instala solo iptv simple sin iptv merge
def inst_tv2():
    # archivos_config()
    addons = ["pvr.iptvsimple"]
    addon_id = 'pvr.iptvsimple'
    lista_addons(addons, False)
    xbmc.sleep(1500)
    res = inst_addon(addon_id)
    if res:
        archivos_config()
        res = addon_inst_confirm(addon_id)
        if res:
            lista_addons(addons, True)
            xbmc.sleep(1500)
            xbmc.log(f"REMOD TV IPTV Simple activado.", level=xbmc.LOGINFO)
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},IPTV Simple activado.,1000,)")
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},En unos 30s estará disponible la sección TV de Kodi.,5000,)")
        else:
            xbmc.log(f"REMOD TV Error activando IPTV Simple.", level=xbmc.LOGINFO)
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},Error activando IPTV Simple.,3000,)")
    else:
        res = addon_borrar_datos(addon_id)
        if res:
            archivos_config()
            lista_addons(addons, True)
            xbmc.sleep(1500)
            xbmc.log(f"REMOD TV Recargando Addon ya instalando IPTV Simple.", level=xbmc.LOGINFO)
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},Recargando IPTV Simple.,1000,)")
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},En unos 30s estará disponible la sección TV de Kodi.,5000,)")


def fuente():
    ### Cada tupla contiene: etiqueta visible, acción, nombre del archivo de icono
    menu_items = [
        (f"Elige la fuente para la sección de TV:", "", "tv.png"),

        ("      1 > Direct (Por defecto)\n                http directos", "lis_dir", ""),
        ("      2 > ACE\n               Protocolo acestream://", "lis,_ace", ""),
        ("      3 > Horus\n             Para addon Horus", "lis_hor", ""),
        ("      4 > ReModTV\n               [ACS] y [M3U8] (VPN necesario para [M3U8])", "lis_rm", "")
    ]

    for label, action, icon_file in menu_items:
        url = build_url({"action": action})
        ### Creamos el ListItem
        li = xbmcgui.ListItem(label=label)
        ### Ruta absoluta al icono
        icon_path = xbmcvfs.translatePath(os.path.join(remodtv_addon_path, 'recursos', 'imagenes', icon_file))
        ###  Asignamos el icono
        li.setArt({'icon': icon_path, 'thumb': icon_path})   # thumb también sirve
        ### Indicamos que es una carpeta (un sub‑menú o acción que abre algo)
        xbmcplugin.addDirectoryItem(handle=HANDLE,
                                    url=url,
                                    listitem=li,
                                    isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)



def actualizar_tv():
    xbmc.executebuiltin(f"Notification({remodtv_addon_name},Reiniciando IPTV Simple.,5000,)")
    addons = ["pvr.iptvsimple"]
    addon_id = 'pvr.iptvsimple'
    res = lista_addons(addons, False)
    xbmc.sleep(1500)
    if res:
        res = lista_addons(addons, True)
        xbmc.sleep(1500)
        if res:
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},En unos 30s estará disponible la sección TV de Kodi.,5000,)")
        else:
            xbmc.executebuiltin(f"Notification({remodtv_addon_name},Error al activar IPTV Simple.,5000,)")
    else:
        xbmc.executebuiltin(f"Notification({remodtv_addon_name},Error al desactivar IPTV Simple.,5000,)")
        
        
def buscar_actualizacion():
    xbmc.log(f"REMOD TV Actualizando Addon Repos.", level=xbmc.LOGINFO)
    xbmc.executebuiltin(f"Notification({remodtv_addon_name},Actualizando Repos...,3000,)")
    xbmc.executebuiltin(f"UpdateAddonRepos()", True)
    xbmc.sleep(3000)
    xbmc.log(f"REMOD TV Actualizando Local Addon.", level=xbmc.LOGINFO)
    xbmc.executebuiltin(f"Notification({remodtv_addon_name},Actualizando Addons...,3000,)")
    xbmc.executebuiltin(f"UpdateLocalAddons()", True)
    xbmc.sleep(3000)
    

def addon_borrar_datos(addon_id):
    addons = ["pvr.iptvsimple"]
    lista_addons(addons, False)
    xbmc.sleep(1500)
    dest = xbmcvfs.translatePath(os.path.join(addons_addon_data, addon_id))
    for nombre in os.listdir(dest):
        # Nos quedamos solo con los que terminan en .xml (ignoramos mayúsculas/minúsculas)
        if nombre.lower().endswith('.xml'):
            ruta_completa = os.path.join(dest, nombre)
            try:
                os.remove(ruta_completa)  # <‑‑ borrado
                return True
            except Exception as e:
                xbmcgui.Dialog().notification(
                    "Error al borrar XML",
                    f"{nombre}: {e}",
                    xbmcgui.NOTIFICATION_ERROR,
                    4000
                )


### configuración del reproductor externo para ACS en Android
def ele_rep():
    dialog = xbmcgui.Dialog()
    rep = dialog.select(
    f"Elige la aplicación de AceStream que tengas instalada",
    [
        ### 0. Ace Stream Media McK
        "Ace Stream Media McK | Android\n     org.acestream.media",
        ### 1. Ace Stream Media ATV
        "Ace Stream Media ATV | Android\n     org.acestream.media.atv",
        ### 2. Ace Stream Media Web
        "Ace Stream Media Web | Android\n     org.acestream.media.web",
        ### 3. Ace Stream Node
        "Ace Stream Node | Android\n      org.acestream.node",
        ### 4. Ace Stream Node Web
        "Ace Stream Node Web | Android\n      org.acestream.node.web",
        ### 5. Ace Stream Core
        "Ace Stream Core | Android\n      org.acestream.core",
        ### 6. Ace Stream Core ATV
        "Ace Stream Core ATV | Android\n      org.acestream.core.atv",
        ### 7. Ace Stream Core Web
        "Ace Stream Core Web | Android\n      org.acestream.core.web",
        ### 8. Ace Stream Live
        "Ace Stream Live | Android\n      org.acestream.live",
        ### 9. MPVkt
        "MPVkt | Android\n        live.mehiz.mpvkt",
        ### 10. MPV
        "MPV | Android\n      is.xyz.mpv",
        ### 11. VLC
        "VLC | Android\n      org.videolan.vlc",
        ### 12. Ace Serve
        "AceServe | Android\n        org.free.aceserve",
        ### 13. AceStream oficial | Windows
        "AceStream oficial | Windows",
        ### 14. VLC y AceStream oficial | Windows
        "VLC y AceStream oficial | Windows",
        ### 15. Dejarlo por defecto
        "Dejarlo por defecto\n      Dejarlo por defecto como cuando se instaló Kodi",
        ### 16. Atras
        "< Volver"
    ]
)
    if rep == 15:
        ### Borramos pcf para dejarlo como antes
        dest = xbmcvfs.translatePath(os.path.join(addons_userdata, 'playercorefactory.xml'))
        xbmcvfs.delete(dest)
                
    if not rep == 16:
        ### variable de la carpeta
        pcf_path = f"playercorefactory{rep}"
        ### copiando archivo playercorefactory.xml desde la variable de la carpeta
        xbmc.log(f"REMOD TV Copiando archivo {pcf_path}", level=xbmc.LOGINFO)
        orig = xbmcvfs.translatePath(os.path.join(remodtv_addon_datos, 'pcf', pcf_path, 'playercorefactory.xml'))
        dest = xbmcvfs.translatePath(os.path.join(addons_userdata, 'playercorefactory.xml'))
        xbmcvfs.copy(orig, dest)
        dialog = xbmcgui.Dialog()
        dialog.ok(f"{remodtv_addon_name}", "Necesitarás reiniciar Kodi para aplicar los cambios.")


### activar sección TV si no está activada (homemenunotvbutton = True = Sección desactivada)
def act_ajuste(ajuste_id):
    ajuste_check = xbmc.getCondVisibility(f'Skin.HasSetting({ajuste_id})') == 1
    if ajuste_check:
        xbmc.executebuiltin(f'Skin.SetBool({ajuste_id},false)')

### pruebas ###


### pruebas ###


### acciones del menu principal
if not ARGS:
    # No hay parámetros → menú principal
    lista_menu_principal()
else:
    action = ARGS.get('action', [None])[0]
    if action == "tv2":
        carp = 'dir'
        inst_tv2()
        ### activar seección TV en menú principal
        ajuste_id = "homemenunotvbutton"
        act_ajuste(ajuste_id)
        
    elif action == "fuente":
        fuente()
    elif action == "actualizar":
        actualizar_tv()
        ajuste_id = "homemenunotvbutton"
        act_ajuste(ajuste_id)
    elif action == "info":
        buscar_actualizacion()
    elif action == "res_ext":
        ele_rep()
    elif action == "lis_dir":
        carp = 'dir'
        archivos_config()
        actualizar_tv()
        lista_menu_principal()
    elif action == "lis_ace":
        carp = 'ace'
        archivos_config()
        actualizar_tv()
        lista_menu_principal()
    elif action == "lis_hor":
        carp = 'hor'
        archivos_config()
        actualizar_tv()
        lista_menu_principal()
    elif action == "lis_rm":
        carp = 'rm'
        archivos_config()
        actualizar_tv()
        lista_menu_principal()
    elif action == "test":
        pass
    else:
        ### Acción desconocida → volver al menú principal
        lista_menu_principal()